#!/usr/bin/env python
# -*- coding: utf-8 -*-
# -*- Python -*-

import sys

import RTC
import OpenRTM_aist

consolein_spec = ["implementation_id", "HelloWorldRcv",
                  "type_name",         "HelloWorldRcv",
                  "description",       "Console input component",
                  "version",           "1.0",
                  "vendor",            "Shinji Kurihara",
                  "category",          "example",
                  "activity_type",     "DataFlowComponent",
                  "max_instance",      "10",
                  "language",          "Python",
                  "lang_type",         "script",
                  ""]

class HelloWorldRcv(OpenRTM_aist.DataFlowComponentBase):
  def __init__(self, manager):
    OpenRTM_aist.DataFlowComponentBase.__init__(self, manager)
    return

  def onInitialize(self):
    self.RecvMsg = RTC.TimedString(RTC.Time(0,0),0)
    self._inport = OpenRTM_aist.InPort("RcvMsg", self.RecvMsg)
    # Set InPort
    self.addInPort("RcvMsg", self._inport)

    print 'Initializing..'
    return RTC.RTC_OK

  def onActivated(self, ec_id):
    print 'Activated.'
    return RTC.RTC_OK
        
  def onExecute(self, ec_id):
    if self._inport.isNew():
      rcvmsg = self._inport.read()
      print rcvmsg.data
    return RTC.RTC_OK

def HelloWorldRcvInit(manager):
  profile = OpenRTM_aist.Properties(defaults_str=consolein_spec)
  manager.registerFactory(profile,
                          HelloWorldRcv,
                          OpenRTM_aist.Delete)


def MyModuleInit(manager):
  HelloWorldRcvInit(manager)

  # Create a component
  comp = manager.createComponent("HelloWorldRcv")

def main():
  # Initialize manager
  mgr = OpenRTM_aist.Manager.init(sys.argv)

  # Set module initialization proceduer
  # This procedure will be invoked in activateManager() function.
  mgr.setModuleInitProc(MyModuleInit)

  # Activate manager and register to naming service
  mgr.activateManager()

  # run the manager in blocking mode
  # runManager(False) is the default
  mgr.runManager()

  # If you want to run the manager in non-blocking mode, do like this
  # mgr.runManager(True)

if __name__ == "__main__":
  main()
