// -*- C++ -*-
/*!
 * @file  Flip100.cpp
 * @brief Flip100
 * @date $Date$
 *
 * $Id$
 */

#include "Flip100.h"

// Module specification
// <rtc-template block="module_spec">
static const char* flip100_spec[] =
  {
    "implementation_id", "Flip100",
    "type_name",         "Flip100",
    "description",       "Flip100",
    "version",           "1.0.0",
    "vendor",            "JSK",
    "category",          "example",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    "conf.default.flipMode", "1",
    // Widget
    "conf.__widget__.flipMode", "radio",
    // Constraints
    "conf.__constraints__.flip_mode", "(-1,0,1)",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
Flip100::Flip100(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_InImageOctetSeqIn("InImageOctetSeq", m_InImageOctetSeq),
    m_OutImageOctetSeqOut("OutImageOctetSeq", m_OutImageOctetSeq)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
Flip100::~Flip100()
{
}



RTC::ReturnCode_t Flip100::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("InImageOctetSeq", m_InImageOctetSeqIn);
  
  // Set OutPort buffer
  addOutPort("OutImageOctetSeq", m_OutImageOctetSeqOut);
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>
  bindParameter("flipMode", m_flipMode, "1");

  return RTC::RTC_OK;
}


RTC::ReturnCode_t Flip100::onFinalize()
{
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Flip100::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Flip100::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t Flip100::onActivated(RTC::UniqueId ec_id)
{
  // �C���[�W�p�������̏�����
  m_imageBuff = NULL;
  m_flipImageBuff = NULL;

  return RTC::RTC_OK;
}


RTC::ReturnCode_t Flip100::onDeactivated(RTC::UniqueId ec_id)
{
  if(m_imageBuff != NULL)
  {
    // �C���[�W�p�������̉��
    cvReleaseImage(&m_imageBuff);
    cvReleaseImage(&m_flipImageBuff);
  }

  return RTC::RTC_OK;
}


RTC::ReturnCode_t Flip100::onExecute(RTC::UniqueId ec_id)
{
  // �V�����f�[�^�̃`�F�b�N
  if (m_InImageOctetSeqIn.isNew()) {
    // InPort�f�[�^�̓ǂݍ���
    m_InImageOctetSeqIn.read();
    
	// �C���[�W�p�������̊m��;;640x480�Ɍ��ߑł�
	m_imageBuff = cvCreateImage(cvSize(640, 480), IPL_DEPTH_8U, 3);
	m_flipImageBuff = cvCreateImage(cvSize(640, 480), IPL_DEPTH_8U, 3);
     
    // InPort�̉摜�f�[�^��IplImage��imageData�ɃR�s�[;;640x480�Ɍ��ߑł�
    memcpy(m_imageBuff->imageData,(void *)&(m_InImageOctetSeq.data[0]),640*480*3);

    // InPort����̉摜�f�[�^�𔽓]����B m_flipMode 0: X������, 1: Y������, -1: �����̎�����
    cvFlip(m_imageBuff, m_flipImageBuff, m_flipMode);

    // �摜�f�[�^�̃T�C�Y�擾
    int len = m_flipImageBuff->nChannels * m_flipImageBuff->width * m_flipImageBuff->height;
    m_OutImageOctetSeq.data.length(len);

    // ���]�����摜�f�[�^��OutPort�ɃR�s�[
    memcpy((void *)&(m_OutImageOctetSeq.data[0]),m_flipImageBuff->imageData,len);

	// ���]�����摜�f�[�^��OutPort����o�͂���B
    m_OutImageOctetSeqOut.write();
  }
		
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t Flip100::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Flip100::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Flip100::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Flip100::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t Flip100::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void Flip100Init(RTC::Manager* manager)
  {
    coil::Properties profile(flip100_spec);
    manager->registerFactory(profile,
                             RTC::Create<Flip100>,
                             RTC::Delete<Flip100>);
  }
  
};


