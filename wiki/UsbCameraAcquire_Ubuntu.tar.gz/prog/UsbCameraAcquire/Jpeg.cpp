#include "Jpeg.h"
#include <stdlib.h>

void init_source(j_decompress_ptr cinfo) {
    mem_src_ptr src = (mem_src_ptr) cinfo->src;
    src->start_of_file = TRUE;

    src->currentPointer = src->sourceBuffer;
    src->readSize = 0;

    src->buffer = (JOCTET *)malloc(JPEG_BUF_SIZE);
    if ( !src->buffer ) {
        perror("malloc");fprintf(stderr,"out of memory!\n");exit(1);
    }
    src->pub.bytes_in_buffer = 0;
    src->pub.next_input_byte = NULL;
}

boolean fill_input_buffer(j_decompress_ptr cinfo) {
    mem_src_ptr src = (mem_src_ptr) cinfo->src;
    size_t nbytes;

    nbytes = (src->sourceBufferSize - src->readSize > JPEG_BUF_SIZE ? JPEG_BUF_SIZE : src->sourceBufferSize - src->readSize);
    memcpy(src->buffer, src->currentPointer, sizeof(JOCTET) * nbytes);

    if(nbytes <= 0) {
        if (src->start_of_file)
            ERREXIT(cinfo, JERR_INPUT_EMPTY);
        WARNMS(cinfo, JWRN_JPEG_EOF);
        src->buffer[0] = (JOCTET) 0xFF;
        src->buffer[1] = (JOCTET) JPEG_EOI;
        nbytes = 2;
    }

    src->currentPointer += nbytes;
    src->readSize += nbytes;

    src->pub.next_input_byte = src->buffer;
    src->pub.bytes_in_buffer = nbytes;
    src->start_of_file = FALSE;

    return TRUE;
}

void skip_input_data(j_decompress_ptr cinfo, long num_bytes) {
    mem_src_ptr src = (mem_src_ptr) cinfo->src;

    src->currentPointer += num_bytes;
    src->readSize += num_bytes;

    if (num_bytes > 0) {
        if (num_bytes > (long) src->pub.bytes_in_buffer) {
            num_bytes -= (long) src->pub.bytes_in_buffer;
            (void) fill_input_buffer(cinfo);
        }

        src->pub.next_input_byte += (size_t) num_bytes;
        src->pub.bytes_in_buffer -= (size_t) num_bytes;
    }
}

void term_source(j_decompress_ptr cinfo) {
    mem_src_ptr src = (mem_src_ptr) cinfo->src;
    if (0) { std::cout << cinfo << std::endl; }
    if (src->buffer) free(src->buffer);
}

static void jvl_jpeg_error_exit(j_common_ptr cinfo)
{
    struct jvl_jpeg_error_mgr *err = (struct jvl_jpeg_error_mgr *)cinfo->err;
    (err->errmgr.output_message)( cinfo );
    longjmp(err->escape, 1);
} 
JpegDecoder::JpegDecoder(){
    mem_src_ptr src;

    cinfo.err = jpeg_std_error(&(jerr.errmgr));
    jerr.errmgr.error_exit = jvl_jpeg_error_exit;
    if(setjmp(jerr.escape)) {
        std::cerr << ";; Jpeg Decode Error" << std::endl;
        //jpeg_destroy_decompress(&cinfo);
        image = NULL;
        std::cerr << ";; Jpeg Decode Error return" << std::endl;
        return;
    }
    jpeg_create_decompress(&(cinfo));

    if (cinfo.src == NULL) {
        cinfo.src = (struct jpeg_source_mgr *) malloc(sizeof(memory_source_mgr));
    }

    src = ( mem_src_ptr ) cinfo.src;
    src->pub.init_source = init_source;
    src->pub.fill_input_buffer = fill_input_buffer;
    src->pub.skip_input_data = skip_input_data;
    src->pub.resync_to_restart = jpeg_resync_to_restart;
    src->pub.term_source = term_source;

    image = NULL;
}

void JpegDecoder::imageDecode(char *buf, int size){
    int row_stride;
    JSAMPROW *row_pointer;
    row_pointer = (JSAMPROW *)malloc (sizeof(JSAMPROW)*1);

    /* set buffer */
    mem_src_ptr src = (mem_src_ptr) cinfo.src;
    src->sourceBuffer = buf;
    src->sourceBufferSize = size;

    (void) jpeg_read_header(&(cinfo), TRUE);

    switch ( cinfo.out_color_space ){
    case JCS_GRAYSCALE:
        if ( image ) free(image);
        image = (unsigned char*) malloc(cinfo.image_width*cinfo.image_height*sizeof(char)*1);
        break;
    case JCS_RGB:
        if ( image ) free(image);
        image = (unsigned char*) malloc(cinfo.image_width*cinfo.image_height*sizeof(char)*3);
        break;
    default:
        std::cerr << "unknown color_space" << std::endl;
        if ( image ) free(image);
        image = (unsigned char*) malloc(cinfo.image_width*cinfo.image_height*sizeof(char)*3);
        break;
    }

    (void) jpeg_start_decompress(&(cinfo));

    row_stride = cinfo.output_width * cinfo.output_components;
    row_pointer[0] = &(image[0]);
    while (cinfo.output_scanline < cinfo.output_height) {
        row_pointer[0] = &(image[0]) + cinfo.output_scanline * row_stride;
        (void)jpeg_read_scanlines(&(cinfo), row_pointer, 1);
        row_pointer[0] += row_stride;
    } 

    (void) jpeg_finish_decompress(&(cinfo));
    free(row_pointer);
}

JpegDecoder::~JpegDecoder(){
    if(cinfo.src) free(cinfo.src);
    jpeg_destroy_decompress(&(cinfo));
    if (image) free(image);
}

/*** 
 ***
 ***/


void init_destination (j_compress_ptr cinfo) {
    mem_dest_ptr dest = (mem_dest_ptr) cinfo->dest;

    dest->buffer = (JOCTET *)malloc(JPEG_BUF_SIZE);
    if ( !dest->buffer ) {
        perror("malloc");fprintf(stderr,"out of memory!\n");exit(1);
    }
    dest->length = 0;
    dest->pub.next_output_byte = dest->buffer;
    dest->pub.free_in_buffer = JPEG_BUF_SIZE;
}

boolean empty_output_buffer (j_compress_ptr cinfo) {
    //mem_dest_ptr dest = (mem_dest_ptr) cinfo->dest;

    fprintf(stderr, "%s : out of memory ... in empty_output_buffer (%d)\n", __PRETTY_FUNCTION__, JPEG_BUF_SIZE);
    exit(1);

    return TRUE;
}

void term_destination (j_compress_ptr cinfo) {
    mem_dest_ptr dest = (mem_dest_ptr) cinfo->dest;

    dest->length = JPEG_BUF_SIZE - dest->pub.free_in_buffer;
    dest->pub.free_in_buffer = 0;
}

JpegEncoder::JpegEncoder(){
    mem_dest_ptr dest;

    image = NULL;

    cinfo.err = jpeg_std_error(&(jerr));
    jpeg_create_compress(&(cinfo));
  
    if (cinfo.dest == NULL) {
        cinfo.dest = (struct jpeg_destination_mgr*) malloc(sizeof(memory_destination_mgr));
    }

    dest = (mem_dest_ptr) cinfo.dest;
    dest->pub.init_destination = init_destination;
    dest->pub.empty_output_buffer = empty_output_buffer;
    dest->pub.term_destination = term_destination;

    cinfo.input_components = 1;
    cinfo.in_color_space   = JCS_GRAYSCALE;  // default
  
    jpeg_set_defaults(&(cinfo));

    setQuality(75);
}

void JpegEncoder::setQuality(int quality){
    this->quality = quality;
    jpeg_set_quality(&(cinfo), quality, TRUE);
}

int JpegEncoder::getQuality(void){
    return this->quality;
}

void JpegEncoder::imageEncode(unsigned char* im, int width, int height, ImageType itype){

    int row_stride;
    JSAMPROW row_pointer[1];
    mem_dest_ptr dest;

    dest = (mem_dest_ptr) cinfo.dest;
  
    dest->pub.next_output_byte = dest->buffer;
    dest->pub.free_in_buffer = JPEG_BUF_SIZE;

    if ( image == NULL ){
        image = (unsigned char*)malloc(width*height*sizeof(char)*3);
    } else {
        free(image);
        image = (unsigned char*)malloc(width*height*sizeof(char)*3);
    }
  
    switch(itype) {
    case IMAGE_GRAY:
        cinfo.input_components = 1;
        cinfo.in_color_space = JCS_GRAYSCALE;
        jpeg_set_colorspace(&(cinfo), JCS_GRAYSCALE);
        break;
    case IMAGE_RGB:
        cinfo.input_components = 3;
        cinfo.in_color_space = JCS_RGB;
        jpeg_set_colorspace(&(cinfo), JCS_RGB);
        break;
    case IMAGE_YUYV:
        cinfo.input_components = 3;
        cinfo.in_color_space = JCS_YCbCr;
        jpeg_set_colorspace(&(cinfo), JCS_YCbCr);
        break;
    default:
        std::cerr << "colorMode(" << itype;
        std::cerr << ") is not supported" << std::endl;
        exit(1);
    }

    jpeg_set_defaults(&(cinfo));
    jpeg_set_quality(&(cinfo), quality, TRUE);

    /* set buffer */
    cinfo.image_width = width;
    cinfo.image_height = height;
    row_stride = cinfo.image_width * cinfo.input_components;

    jpeg_start_compress(&(cinfo), TRUE);
  
    if ( cinfo.in_color_space == JCS_YCbCr && itype == IMAGE_YUYV ) {
    
        while(cinfo.next_scanline < cinfo.image_height) {
            static unsigned char buffer[1024*3];/* yuv <- yuyv */
            for ( int i = 0; i  < width; i++ ){
                unsigned char *buf_ptr;
                buf_ptr = &(im[0]) + cinfo.next_scanline * cinfo.image_width * 2;
                buffer[i*3+0] = buf_ptr[i*2+0];
                buffer[i*3+1] = buf_ptr[i*2+1];
                buffer[i*3+2] = buf_ptr[i*2+3];
            }
            //row_pointer[0] = im->getBuffer() + cinfo.next_scanline * row_stride;
            row_pointer[0] = buffer;
            jpeg_write_scanlines(&(cinfo), row_pointer, 1);
        }
    }else{
        while(cinfo.next_scanline < cinfo.image_height) {
            row_pointer[0] = &(im[0]) + cinfo.next_scanline * row_stride;
            jpeg_write_scanlines(&(cinfo), row_pointer, 1);
        }
    }
    
    jpeg_finish_compress(&(cinfo));

    memcpy(image, dest->buffer, width * height *3);

    free(dest->buffer);
}

JpegEncoder::~JpegEncoder(){
    if(cinfo.dest) free(cinfo.dest);
    jpeg_destroy_compress(&(cinfo));
    if (image) free(image);
}


