// -*- C++ -*-
/*!
 * @file  UsbCameraAcquire.cpp
 * @brief Sequence InPort component
 *
 */
#include "UsbCameraAcquire.h"

char windowName[] = "UsbCameraAcquire";

// Module specification
// <rtc-template block="module_spec">
static const char* col_spec[] =
  {
    "implementation_id", "UsbCameraAcquire",
    "type_name",         "UsbCameraAcquire",
    "description",       "UsbCameraAcquire component",
    "version",           "1.0",
    "vendor",            "Tomoaki Yoshikai, JSK",
    "category",          "example",
    "activity_type",     "DataFlowComponent",
    "max_instance",      "10",
    "language",          "C++",
    "lang_type",         "compile",
    "conf.default.print_name",         "0",
    ""
  };
// </rtc-template>

UsbCameraAcquire::UsbCameraAcquire(RTC::Manager* manager)
  : RTC::DataFlowComponentBase(manager),
    // <rtc-template block="initializer">
    m_ImageOut("imageout", m_ImageOutData)
    // </rtc-template>
{
}

UsbCameraAcquire::~UsbCameraAcquire()
{
}

void UsbCameraAcquire::init_v4l2(void){

    if((capfd = open("/dev/video0", O_RDWR)) < 0) {
        fprintf(stderr, "Couldn't find any camera\n");
    }
    
    struct v4l2_capability vd;

    memset(&vd, 0, sizeof(struct v4l2_capability));
    if(ioctl(capfd, VIDIOC_QUERYCAP, &vd) < 0) {
        perror("ioctl(VIDIOC_QUERYCAP)");
        return;
    }

    fprintf(stderr, ";; video capabilities /dev/video0\n");
    fprintf(stderr, ";; vd.driver         = %s\n", vd.driver);
    fprintf(stderr, ";; vd.card           = %s\n", vd.card);
    fprintf(stderr, ";; vd.buf_info       = %s\n", vd.bus_info);
    fprintf(stderr, ";; vd.version        = %d\n", vd.version);
    fprintf(stderr, ";; vd.capabilities   = 0x%08x ", vd.capabilities);
    if (vd.capabilities & V4L2_CAP_VIDEO_CAPTURE)
        fprintf(stderr, " VIDEO_CAPTURE");
    if (vd.capabilities & V4L2_CAP_VIDEO_OUTPUT)
        fprintf(stderr, " VIDEO_OUTPUT");
    if (vd.capabilities & V4L2_CAP_VIDEO_OVERLAY)
        fprintf(stderr, " VIDEO_OVERLAY");
    if (vd.capabilities & V4L2_CAP_VBI_CAPTURE)
        fprintf(stderr, " VBI_CAPTURE");
    if (vd.capabilities & V4L2_CAP_VBI_OUTPUT)
        fprintf(stderr, " VBI_OUTPUT");
    #ifdef V4L2_CAP_SLICED_VBI_CAPTURE
    if (vd.capabilities & V4L2_CAP_SLICED_VBI_CAPTURE)
        fprintf(stderr, " SLICED_VBI_CAPTURE");
    #endif
    #ifdef V4L2_CAP_SLICED_VBI_OUTPUT
    if (vd.capabilities & V4L2_CAP_SLICED_VBI_OUTPUT)
        fprintf(stderr, " VBI_SLICED_OUTPUT");
    #endif
    if (vd.capabilities & V4L2_CAP_RDS_CAPTURE)
        fprintf(stderr, " RDS_CAPTURE");
    #ifdef V4L2_CAP_VIDEO_OUTPUT_OVERLAY
    if (vd.capabilities & V4L2_CAP_VIDEO_OUTPUT_OVERLAY)
        fprintf(stderr, " VIDEO_OUTPUT_OVERLAY");
    #endif
    if (vd.capabilities & V4L2_CAP_TUNER)
        fprintf(stderr, " TUNER");
    if (vd.capabilities & V4L2_CAP_AUDIO)
        fprintf(stderr, " AUDIO");
    if (vd.capabilities & V4L2_CAP_RADIO)
        fprintf(stderr, " RADIO");
    if (vd.capabilities & V4L2_CAP_READWRITE)
        fprintf(stderr, " READWRITE");
    if (vd.capabilities & V4L2_CAP_ASYNCIO)
        fprintf(stderr, " ASYNCIO");
    if (vd.capabilities & V4L2_CAP_STREAMING)
        fprintf(stderr, " STREAMING");
    fprintf(stderr, "\n");

    if ((vd.capabilities & V4L2_CAP_VIDEO_CAPTURE) == 0) {
        perror("Video capture not supported.\n");
        return;
    }
    if (!(vd.capabilities & V4L2_CAP_STREAMING)) {
        perror("Device does not support streaming i/o\n");
        return;
    }
    
    struct v4l2_fmtdesc fmtdesc[16];
    memset(&fmtdesc, 0, sizeof(struct v4l2_fmtdesc)*16);
    for (int i = 0; i < 16; i++) {
        fmtdesc[i].index = i;
        fmtdesc[i].type  = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        if (ioctl(capfd, VIDIOC_ENUM_FMT, &fmtdesc[i]) < 0) {
            break;
        }
        /* RGB 24bitに対応しているか探してみる */
        fprintf(stderr, ";; fd[%d].pixelfotmat = %x\n",
                i, fmtdesc[i].pixelformat);
        fprintf(stderr, ";;      .descriptoin = %s\n",
                fmtdesc[i].description);
        if (fmtdesc[i].pixelformat == V4L2_PIX_FMT_RGB24) {
            fprintf(stderr, "V4L2_PIX_FMT_RGB24\n");
        }
        if (fmtdesc[i].pixelformat == V4L2_PIX_FMT_BGR24) {
            fprintf(stderr, "V4L2_PIX_FMT_BGR24\n");
        }
    }

    /* set format in */
    bool success = false;

    memset(&v4l2fmt, 0, sizeof(struct v4l2_format));
    v4l2fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    v4l2fmt.fmt.pix.width = m_Width;
    v4l2fmt.fmt.pix.height =  m_Height;

    /* try to check yuyv */
    v4l2fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
    v4l2fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;
    if(ioctl(capfd, VIDIOC_S_FMT, &v4l2fmt)>=0){
        fprintf(stderr, ";; set video format  = V4L2_PIX_FMT_YUYV\n");
        success = true;
        goto set_format_success;
    }

    /* try to check yuyv */
    v4l2fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUV420;
    v4l2fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;
    if(ioctl(capfd, VIDIOC_S_FMT, &v4l2fmt)>=0){
        fprintf(stderr, ";; set video format  = V4L2_PIX_FMT_YUV420\n");
        success = true;
        goto set_format_success;
    }

    /* try to check mpeg */
    v4l2fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG;
    v4l2fmt.fmt.pix.field = V4L2_FIELD_ANY;
    if(ioctl(capfd, VIDIOC_S_FMT, &v4l2fmt)>=0){
        fprintf(stderr, ";; set video format  = V4L2_PIX_FMT_MJPEG\n");
        success = true;
        goto set_format_success;
    }

set_format_success:
    /* error */
    if (!success) {
        char str[256];
        sprintf(str, ";; ERROR unable to set format width=%d, height=%d ", m_Width, m_Height);
        perror(str);
        return;
    }

    if (((int)v4l2fmt.fmt.pix.width != m_Width) ||
        ((int)v4l2fmt.fmt.pix.height != m_Height)) {
        std::cerr << "Format asked unavailable get" << std::endl;
    }

    /* set framerate */
    struct v4l2_streamparm* setfps;
    setfps=(struct v4l2_streamparm *) calloc(1, sizeof(struct v4l2_streamparm));
    memset(setfps, 0, sizeof(struct v4l2_streamparm));
    setfps->type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    setfps->parm.capture.timeperframe.numerator=1;
    setfps->parm.capture.timeperframe.denominator=30;
    if(ioctl(capfd, VIDIOC_S_PARM, setfps)<0){
        perror(";; Unable to set framerate. ");
    }
    free(setfps);

    /* request buffers */
    struct v4l2_requestbuffers rb;
    memset(&rb, 0, sizeof(struct v4l2_requestbuffers));
    rb.count = NB_BUFFER;
    rb.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    rb.memory = V4L2_MEMORY_MMAP;

    if(ioctl(capfd, VIDIOC_REQBUFS, &rb)<0){
        perror("Unable to allocate buffers.\n");
        return;
    }

    /* map the buffers */
    for (int i = 0; i < NB_BUFFER; i++) {
        memset(&v4l2buf, 0, sizeof(struct v4l2_buffer));
        v4l2buf.index = i;
        v4l2buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        v4l2buf.memory = V4L2_MEMORY_MMAP;
        if(ioctl(capfd, VIDIOC_QUERYBUF, &v4l2buf)<0){
            perror("Unable to query buffer.\n");
            return;
        }
        mem[i] = mmap(0 /* start anywhere */ ,
                      v4l2buf.length, PROT_READ, MAP_SHARED, capfd,
                      v4l2buf.m.offset);
        if (mem[i] == MAP_FAILED) {
            perror("Unable to map buffer\n");
            return;
        }
    }
    /* Queue the buffers. */
    for (int i = 0; i < NB_BUFFER; ++i) {
        memset(&v4l2buf, 0, sizeof(struct v4l2_buffer));
        v4l2buf.index = i;
        v4l2buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        v4l2buf.memory = V4L2_MEMORY_MMAP;
        if(ioctl(capfd, VIDIOC_QBUF, &v4l2buf)<0){
            perror("Unable to queue buffer.\n");
            return;
        }
    }

    /* start capture */
    int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if(ioctl(capfd, VIDIOC_STREAMON, &type) < 0){
        perror("Unable to start capture.\n");
        return;
    }
}

void UsbCameraAcquire::capture_v4l2(void){
  //copy from memory
  memset(&v4l2buf, 0, sizeof(struct v4l2_buffer));
  v4l2buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
  v4l2buf.memory = V4L2_MEMORY_MMAP;
  /* dequeue buffer since capture process is completed */
  if(ioctl(capfd, VIDIOC_DQBUF, &v4l2buf)<0){
    perror("Unable to dequeue buffer.\n");
  }
  unsigned char *srcimg = (unsigned char *)mem[v4l2buf.index];
  switch (v4l2fmt.fmt.pix.pixelformat) {
  case V4L2_PIX_FMT_MJPEG:
      if(v4l2buf.bytesused <= HEADERFRAME1) { /* Prevent crash on empty image */
          perror("Ignoring empty buffer ...\n");
      }

      if ( srcimg[0] == 0xff &&
           srcimg[1] == 0xd8 ) {
	  JpegDecoder* jp;
	  jp = new JpegDecoder();
          jp->imageDecode((char *)srcimg, v4l2buf.bytesused);
	  unsigned char *dstimg = (unsigned char *)malloc(m_Width * m_Height * sizeof(char) * 3);

          memcpy(dstimg, jp->getImage(), m_Width*m_Height*3);

          for(int yy = 0 ; yy < m_Height ; yy++) {
              for(int xx = 0 ; xx < m_Width ; xx++) {
                  int i = yy*m_Width+xx;

                  image->imageData[i*3+0] = (int)dstimg[i*3+2];
                  image->imageData[i*3+1] = (int)dstimg[i*3+1];
                  image->imageData[i*3+2] = (int)dstimg[i*3+0];
              }
          }
	  delete(jp);
	  free(dstimg);
      } else {
          std::cerr << "Error: Not a Jpeg file " << std::endl;
      }

      break;
  default:
      double r, g, b;
      for(int yy = 0 ; yy < m_Height ; yy++) {
          for(int xx = 0 ; xx < m_Width ; xx+=2) {
              int i = yy*m_Width+xx;
              int y, u, v;

              y = srcimg[i*2+0];
              u = srcimg[i*2+1];
              v = srcimg[i*2+3];
        
              r = y - 0.0000 * (u - 128) + 1.4075 * (v - 128); 
              g = y - 0.3455 * (u - 128) - 0.7169 * (v - 128); 
              b = y + 1.7790 * (u - 128) - 0.0000 * (v - 128); 

              if ( r < 0 ) r  = 0; if ( r > 255 ) r  = 255;
              if ( g < 0 ) g  = 0; if ( g > 255 ) g  = 255;
              if ( b < 0 ) b  = 0; if ( b > 255 ) b  = 255;	  

              image->imageData[i*3+0] = (int)b;
              image->imageData[i*3+1] = (int)g;
              image->imageData[i*3+2] = (int)r;

              i = yy*m_Width+xx+1;

              y = srcimg[i*2+0];
      
              r = y - 0.0000 * (u - 128) + 1.4075 * (v - 128); 
              g = y - 0.3455 * (u - 128) - 0.7169 * (v - 128); 
              b = y + 1.7790 * (u - 128) - 0.0000 * (v - 128); 

              if ( r < 0 ) r  = 0; if ( r > 255 ) r  = 255;
              if ( g < 0 ) g  = 0; if ( g > 255 ) g  = 255;
              if ( b < 0 ) b  = 0; if ( b > 255 ) b  = 255;	  

              image->imageData[i*3+0] = (int)b;
              image->imageData[i*3+1] = (int)g;
              image->imageData[i*3+2] = (int)r;
          }
      }      
      break;
  }

  /* Queue the buffers. */
  if(ioctl(capfd, VIDIOC_QBUF, &v4l2buf)<0){
    perror("Unable to requeue buffer.\n");
  }
}

void UsbCameraAcquire::sync_v4l2(void){
  int ok = 0;
  fd_set fds;
  struct timeval tv;
  while (!ok) {
    tv.tv_sec = 1;
    tv.tv_usec = 0;
    FD_ZERO(&fds);
    FD_SET(capfd, &fds);
    switch(select(capfd + 1, &fds, NULL, NULL, &tv)) {
    case -1:
      if (errno == EINTR) {
        continue;
      }
      printf("wait capture(select()) error.\n");
      munmap(mem,v4l2buf.length);
    case 0:
      printf("capture timeout.\n");
      munmap(mem,v4l2buf.length);
    default:
      ok = 1;
      break;
    }
  }
}

RTC::ReturnCode_t UsbCameraAcquire::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addOutPort( "imageout", m_ImageOut );

  // Set service provider to Ports

  // Set CORBA Service Ports

  m_Width = 320;
  m_Height = 240;

  // </rtc-template>

  if (m_file.empty())
    bindParameter("file", m_file, "UsbCameraAcquireTest.conf");
  bindParameter("config", m_config, "UsbCameraAcquire0");
  bindParameter( "Color", m_Color, "0" );
  bindParameter( "WaitTime", m_WaitTime, "30" );
  
    return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t UsbCameraAcquire::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t UsbCameraAcquire::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t UsbCameraAcquire::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

RTC::ReturnCode_t UsbCameraAcquire::onActivated(RTC::UniqueId ec_id)
{
  image = cvCreateImage( cvSize( m_Width, m_Height ), IPL_DEPTH_8U, 3 );
  cvSet( image, cvScalarAll( 0 ), NULL );

  //カメラの初期化
  init_v4l2();
  
  fprintf(stderr, "Finish initialization\n");
  return RTC::RTC_OK;
}


RTC::ReturnCode_t UsbCameraAcquire::onDeactivated(RTC::UniqueId ec_id)
{
  munmap(mem,v4l2buf.length);
  close(capfd);
  cvDestroyWindow( windowName );

  return RTC::RTC_OK;
}


RTC::ReturnCode_t UsbCameraAcquire::onExecute(RTC::UniqueId ec_id)
{
  try
  {
    //capture image
    capture_v4l2();
    //wait until capture is finished
    sync_v4l2();
    //アウトポートにデータを出力
    m_ImageOutData.pixels.length(m_Width*m_Height*3);
    m_ImageOutData.width  = m_Width;
    m_ImageOutData.height = m_Height;
    memcpy((void *)&(m_ImageOutData.pixels[0]), image->imageData,m_Width*m_Height*3);
    m_ImageOut.write();

  }
  catch(const std::runtime_error &e)
  {
      // 失敗しても続行
      std::cerr << e.what() << std::endl;
  }
  //

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t UsbCameraAcquire::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t UsbCameraAcquire::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t UsbCameraAcquire::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t UsbCameraAcquire::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t UsbCameraAcquire::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

extern "C"
{
 
  void UsbCameraAcquireInit(RTC::Manager* manager)
  {
    coil::Properties profile(col_spec);
    manager->registerFactory(profile,
                             RTC::Create<UsbCameraAcquire>,
                             RTC::Delete<UsbCameraAcquire>);
  }
  
};


