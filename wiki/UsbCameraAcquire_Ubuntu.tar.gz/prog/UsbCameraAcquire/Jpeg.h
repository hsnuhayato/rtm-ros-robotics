#ifndef _JPEG_H_
#define _JPEG_H_

#include <stdio.h>
#include <string.h>
#include <iostream>
namespace Jpeg{
  extern "C" {
#include <stdio.h>
#include <jpeglib.h>
#include <jerror.h>
  }
}

using namespace Jpeg;

enum ImageType {
    IMAGE_BW,
    IMAGE_GRAY,
    IMAGE_YUYV,
    IMAGE_YYUV,
    IMAGE_YUV,
    IMAGE_YUV420,
    IMAGE_RGB,
    IMAGE_LABEL,
    IMAGE_DEPTH,
    IMAGE_JPEG,
    IMAGE_FLOAT,
};

/*
 * based on 
 *   jvl_jpeg.h : JPEG encoder and decoder
 *	v1.0	original code is written by yoro in 020828
 */

#define JPEG_BUF_SIZE 614400
typedef struct {
  struct jpeg_source_mgr pub;
  JOCTET *buffer;
  boolean start_of_file;
  
  char *sourceBuffer;
  unsigned int sourceBufferSize;

  char *currentPointer;
  unsigned int readSize;
} memory_source_mgr;
typedef memory_source_mgr * mem_src_ptr;

/** **/
#include <setjmp.h>
struct jvl_jpeg_error_mgr {
  struct jpeg_error_mgr errmgr;
  jmp_buf escape;
};

class JpegDecoder {
  struct jpeg_decompress_struct cinfo;
  struct jvl_jpeg_error_mgr jerr;
  unsigned char *image;

 public:
  JpegDecoder();
  ~JpegDecoder();

  /**
   * Decode image from JPEG data, and store to jvl_IMAGE.
   * @param src JPEG data.
   * @param srcSize Size of the JPEG data.
 */
  void imageDecode(char *buf, int size);
  unsigned char *getImage() { return image;}  
};

typedef struct {
  struct jpeg_destination_mgr pub;
  JOCTET *buffer;
  int length;
} memory_destination_mgr;
typedef memory_destination_mgr * mem_dest_ptr;

class JpegEncoder {
  struct jpeg_compress_struct cinfo;
  struct jpeg_error_mgr jerr;
  unsigned char *image;
  int quality;
  
 public:

  JpegEncoder();
  ~JpegEncoder();

  /**
   * Set the quality of compression.
   * quality is expected from 0 to 100.
   */
  void setQuality(int quality);

  /**
   * Get the quality of compression.
   * quality is expected from 0 to 100.
   */
  int getQuality();
  
  /**
   * Encode image to JPEG data, and store to dest.
   * Return the length of JPEG data.
   * JPEG data is stored to the dest.
   * @param image The original image data to be compressed.
   */
  void imageEncode(unsigned char* im, int width, int height, ImageType itype);

  /**
   * Accessors
   */
  int usedMemorySize() { return ((mem_dest_ptr) cinfo.dest)->length;};
  char *destinationBuffer() { return (char *)((mem_dest_ptr) cinfo.dest)->buffer;};  
  unsigned char *getImage() { return image;}
};

#endif
