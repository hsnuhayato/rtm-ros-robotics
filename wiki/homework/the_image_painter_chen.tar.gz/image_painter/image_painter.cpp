#include <ros/ros.h>
#include <opencv/cv.h>
#include <opencv/highgui.h>
#include <cv_bridge/CvBridge.h>
#include <image_transport/image_transport.h>

#include <dynamic_reconfigure/server.h>
#include <driver_base/SensorLevels.h>
#include "image_painter/ImagePaintConfig.h"
#include <boost/bind.hpp>

#define NONE 0
#define BLACK 1
#define WHITE 2
#define RED 3
#define GREEN 4
#define BLUE 5
#define YELLOW 6
#define PURPLE 7
#define ERASE 8
#define CLEAN 9

static const char WINDOW[] = "Image Painter";
bool is_uninitialized = true;
bool ColorFlags [10];

void changeflags(int color){
  for(int i=0;i<10;i++){
    ColorFlags[i]=false;
  }
  ColorFlags[color]=true;
}

class ImagePainter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  sensor_msgs::CvBridge bridge_;
  IplImage *result, *draw;
  int key,csize;

  typedef dynamic_reconfigure::Server<image_painter::ImagePaintConfig> Server;
  Server srv_;
  Server::CallbackType f;


public:
  ImagePainter() : it_(nh_),csize(1)
  {
    image_sub_ = it_.subscribe("image", 1, &ImagePainter::imageCb, this);
    result = cvCreateImage(cvSize(640,480), IPL_DEPTH_8U, 3);
    draw = cvCreateImage(cvSize(640,480), IPL_DEPTH_8U, 3);

    f = boost::bind(&ImagePainter::configure, this, _1, _2);
    srv_.setCallback(f);

    cv::namedWindow(WINDOW);
    cvSetMouseCallback(WINDOW, &ImagePainter::on_mouse, this);
    changeflags(WHITE);
  }
  ~ImagePainter()
  {
    cv::destroyWindow(WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    IplImage* tmpimg;
    try {
      tmpimg = bridge_.imgMsgToCv(msg, "bgr8");
    } catch (sensor_msgs::CvBridgeException& ex){
      ROS_ERROR("cv_bridge exception: %s", ex.what());
      return;
    }
    process(tmpimg, result, draw);

    if(is_uninitialized){
      changeflags(CLEAN);
      is_uninitialized=false;
    }else if(ColorFlags[CLEAN]){
      changeflags(NONE);
    }
    key = cvWaitKey(7);
    switch(key){
    case '0':
      changeflags(NONE);break;
    case '1':
      changeflags(BLACK);break;
    case '2':
      changeflags(WHITE);break;
    case '8':
      changeflags(ERASE);break;
    case '9':
      changeflags(CLEAN);break;
    }
    cv::imshow(WINDOW, result);
    cv::waitKey(7);
  }

  void process(IplImage *src0, IplImage *dst, IplImage *draw) {
    uchar *pS, *pD, *pd;
    uchar *dataS, *dataD,*datad;
    int bpp,step,x,y;
    CvSize size;
    double yS,prS,pbS;
    IplImage *src = cvCreateImage(cvSize(640,480), IPL_DEPTH_8U, 3);
    cvCopy( src0, src, NULL );
    bpp = ((src0->depth & 255) / 8 ) *src0->nChannels;
    cvGetRawData(src0, &dataS, &step, &size);
    cvGetRawData(src, &dataD, NULL, NULL);

    for(y=0; y<size.height; y++) {
      // pS = dataS + step*size.height/4 + bpp*size.width/4;
      // pD = dataD + step*size.height/4 + bpp*size.width*3/4;
      pS = dataS;
      pD = dataD + bpp*size.width;
      for(x=0; x<size.width; x++) {
	*pD = pS[0];
	*(pD+1) = pS[1];
	*(pD+2) = pS[2];
	pS = pS + bpp;
	pD = pD - bpp ;
      }
      dataS += step;
      dataD += step;
    }

    cvCopy( src, dst, NULL );
    cvGetRawData(src, &dataS, &step, &size);
    cvGetRawData(dst, &dataD, NULL, NULL);
    cvGetRawData(draw, &datad, NULL, NULL);

    for(y=size.height*csize/16; y<(size.height*(16-csize)/16); y++) {
      pS = dataS+step*size.height*csize/16+bpp*size.width/16;
      pD = dataD+step*size.height*csize/16+bpp*size.width/16;
      pd = datad+step*size.height*csize/16+bpp*size.width/16;
      for(x=size.width*csize/16; x<(size.width*(16-csize)/16); x++) {
	yS = (int)(0.114 * pS[0] +0.587 * pS[1] +0.299 * pS[2]);
	prS = (int)(-0.081 * pS[0] -0.419 * pS[1] +0.50 * pS[2]);
	pbS = (int)(0.50 * pS[0] -0.331 * pS[1] -0.169 * pS[2]);
	if(is_uninitialized){
	  *pd = 0;*(pd+1) = 0;*(pd+2) = 0;
	}else if(!ColorFlags[CLEAN]){
	  if((yS>100)&&(yS<240)&&(prS>20)&&(prS<60)&&(pbS>-35)&&(pbS<-2)){
	    if(ColorFlags[RED]){
	      *pd = 1;*(pd+1) = 1;*(pd+2) = 255;
	    }else if(ColorFlags[GREEN]){
	      *pd = 1;*(pd+1) = 255;*(pd+2) = 1;
	    }else if(ColorFlags[BLUE]){
	      *pd = 255;*(pd+1) = 1;*(pd+2) = 1;
	    }else if(ColorFlags[WHITE]){
	      *pd = 255;*(pd+1) = 255;*(pd+2) = 255;
	    }else if(ColorFlags[BLACK]){
	      *pd = 1;*(pd+1) = 1;*(pd+2) = 1;
	    }else if(ColorFlags[YELLOW]){
	      *pd = 1;*(pd+1) = 255;*(pd+2) = 255;
	    }else if(ColorFlags[PURPLE]){
	      *pd = 255;*(pd+1) = 1;*(pd+2) = 255;
	    }else if(ColorFlags[ERASE]){
	      *pd = 0;*(pd+1) = 0;*(pd+2) = 0;
	    }
	  }
	  if(*pd != 0||*(pd+1) != 0||*(pd+2) != 0){
	    *pD = pd[0];*(pD+1) = pd[1];*(pD+2) = pd[2];
	  }else{
	    *pD = pS[0]; *(pD+1) = pS[1];*(pD+2) = pS[2];
	  }
	}else{
	  *pd = 0;*(pd+1) = 0;*(pd+2) = 0;
	  *pD = pS[0]; *(pD+1) = pS[1];*(pD+2) = pS[2];
	}
	pS += bpp; pD += bpp; pd += bpp;
      }
      dataS += step; dataD += step; datad += step;
    }
    cvGetRawData(dst, &dataD, NULL, NULL);
    for(y=size.height*1/8; y<size.height*7/8; y++) {
      pD = dataD+step*size.height/8;
      for(x=0; x<size.width/16; x++) {
	if(80<y && y<120){*pD = 0; *(pD+1) = 0; *(pD+2) = 255;}
	if(120<y && y<160){*pD = 0; *(pD+1) = 255; *(pD+2) = 0;}
	if(160<y && y<200){*pD = 255; *(pD+1) = 0; *(pD+2) = 0;}
	if(200<y && y<240){*pD = 255; *(pD+1) = 255; *(pD+2) = 255;}
	if(240<y && y<280){*pD = 1; *(pD+1) = 1; *(pD+2) = 1;}
    	if(280<y && y<320){*pD = 0; *(pD+1) = 255; *(pD+2) = 255;}
    	if(320<y && y<360){*pD = 255; *(pD+1) = 0; *(pD+2) = 255;}
    	if(360<y && y<400){*pD = 255; *(pD+1) = 255; *(pD+2) = 0;}
    	pD += bpp;
      }
      dataD += step;
    }
  }

  void configure(image_painter::ImagePaintConfig& config, uint32_t level){
    // if (level >= (uint32_t)driver_base::SensorLevels::RECONFIGURE_STOP)
    //   stop();
    //    ROS_INFO("%s",config.color_mode.c_str());
    if(config.color_mode == "none") changeflags(NONE);
    else if(config.color_mode == "white") changeflags(WHITE);
    else if(config.color_mode == "black") changeflags(BLACK);
    else if(config.color_mode == "red") changeflags(RED);
    else if(config.color_mode == "green") changeflags(GREEN);
    else if(config.color_mode == "blue") changeflags(BLUE);
    else if(config.color_mode == "yellow") changeflags(YELLOW);
    else if(config.color_mode == "purple") changeflags(PURPLE);
    else if(config.color_mode == "erase") changeflags(ERASE);
    else if(config.color_mode == "clean") changeflags(CLEAN);
    else ROS_WARN("no matching");
    csize = config.Campus_size;
  }

  static void on_mouse( int event, int x, int y, int flags, void* parameters ){
    switch (event){
    case CV_EVENT_LBUTTONDOWN:
      if(0<x&&x<40){
	if(80<y && y<120) changeflags(RED);
	if(120<y && y<160) changeflags(GREEN);
	if(160<y && y<200) changeflags(BLUE);
	if(200<y && y<240) changeflags(WHITE);
	if(240<y && y<280) changeflags(BLACK);
	if(280<y && y<320) changeflags(YELLOW);
	if(320<y && y<360) changeflags(PURPLE);
	if(360<y && y<400) changeflags(ERASE);
      }
    }
  }
};

/* main */
int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_painter");
  ImagePainter IP;
  ros::spin();
  return 0;
}

