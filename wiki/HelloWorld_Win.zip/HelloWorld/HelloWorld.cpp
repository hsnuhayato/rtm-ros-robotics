// -*- C++ -*-
/*!
 * @file  HelloWorld.cpp
 * @brief Hello World Sample
 * @date $Date$
 *
 * $Id$
 */

#include "HelloWorld.h"

// Module specification
// <rtc-template block="module_spec">
static const char* helloworld_spec[] =
  {
    "implementation_id", "HelloWorld",
    "type_name",         "HelloWorld",
    "description",       "Hello World Sample",
    "version",           "1.0.0",
    "vendor",            "JSK",
    "category",          "Sample",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
HelloWorld::HelloWorld(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager)

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
HelloWorld::~HelloWorld()
{
}



RTC::ReturnCode_t HelloWorld::onInitialize()
{
	std::cerr << "Initializing.. " << std::endl;
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  
  // Set OutPort buffer
  
  // Set service provider to Ports
  
  // Set service consumers to Ports
  
  // Set CORBA Service Ports
  
  // </rtc-template>

  return RTC::RTC_OK;
}


RTC::ReturnCode_t HelloWorld::onFinalize()
{
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t HelloWorld::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t HelloWorld::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t HelloWorld::onActivated(RTC::UniqueId ec_id)
{
	std::cerr << "Activating.. " << std::endl;
  return RTC::RTC_OK;
}


RTC::ReturnCode_t HelloWorld::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}


RTC::ReturnCode_t HelloWorld::onExecute(RTC::UniqueId ec_id)
{
	std::cerr << "Hello world! " << std::endl;
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t HelloWorld::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t HelloWorld::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t HelloWorld::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t HelloWorld::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t HelloWorld::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/



extern "C"
{
 
  void HelloWorldInit(RTC::Manager* manager)
  {
    coil::Properties profile(helloworld_spec);
    manager->registerFactory(profile,
                             RTC::Create<HelloWorld>,
                             RTC::Delete<HelloWorld>);
  }
  
};


