// -*- C++ -*-
/*!
 * @file  HelloWorldSend.cpp * @brief HelloWorldSend * $Date$ 
 *
 * $Id$ 
 */
#include "HelloWorldSend.h"

// Module specification
// <rtc-template block="module_spec">
static const char* helloworldsend_spec[] =
  {
    "implementation_id", "HelloWorldSend",
    "type_name",         "HelloWorldSend",
    "description",       "HelloWorldSend",
    "version",           "1.0",
    "vendor",            "JSK",
    "category",          "example",
    "activity_type",     "SPORADIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "10",
    "language",          "C++",
    "lang_type",         "compile",
    // Configuration variables
    ""
  };
// </rtc-template>

HelloWorldSend::HelloWorldSend(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_SendMsgOut("SendMsg", m_SendMsg)

    // </rtc-template>
{
}

HelloWorldSend::~HelloWorldSend()
{
}


RTC::ReturnCode_t HelloWorldSend::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers

  // Set OutPort buffer
  addOutPort("SendMsg", m_SendMsgOut);

  // Set service provider to Ports

  // Set service consumers to Ports

  // Set CORBA Service Ports

  // </rtc-template>

  // <rtc-template block="bind_config">
  // Bind variables and configuration variable

  // </rtc-template>

  std::cerr << "Initializing.." << std::endl;
  return RTC::RTC_OK;
}


/*
RTC::ReturnCode_t HelloWorldSend::onFinalize()
{
  return RTC::RTC_OK;
}
*/
/*
RTC::ReturnCode_t HelloWorldSend::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/
/*
RTC::ReturnCode_t HelloWorldSend::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

RTC::ReturnCode_t HelloWorldSend::onActivated(RTC::UniqueId ec_id)
{
  std::cerr << "Activated." << std::endl;
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t HelloWorldSend::onDeactivated(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

RTC::ReturnCode_t HelloWorldSend::onExecute(RTC::UniqueId ec_id)
{
  m_SendMsg.data = "Hello World!";
  m_SendMsgOut.write();
  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t HelloWorldSend::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/
/*
RTC::ReturnCode_t HelloWorldSend::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/
/*
RTC::ReturnCode_t HelloWorldSend::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/
/*
RTC::ReturnCode_t HelloWorldSend::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/
/*
RTC::ReturnCode_t HelloWorldSend::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


extern "C"
{
 
  void HelloWorldSendInit(RTC::Manager* manager)
  {
    coil::Properties profile(helloworldsend_spec);
    manager->registerFactory(profile,
                             RTC::Create<HelloWorldSend>,
                             RTC::Delete<HelloWorldSend>);
  }
  
};



